Included files:

### File: metal-cpp_macOS12_iOS15
- **URL**: https://developer.apple.com/metal/cpp/files/metal-cpp_macOS12_iOS15.zip
- **Reason for including:** currently cannot download file via tooling like *curl* or *bazel*.

